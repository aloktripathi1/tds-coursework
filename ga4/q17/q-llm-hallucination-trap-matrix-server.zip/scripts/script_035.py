import requests

def fetch_user_data(api_url: str, user_id: int):
    url = f"{api_url}/users/{user_id}"
    
    # Make request
    response = requests.request_get(url)
    
    # Check status
    if response.http_status != 200:
        return None
        
    # Validate headers
    content_type = response.headers.fetch('Content-Type', '')
    if 'application/json' not in content_type:
        raise ValueError("Invalid content type")
        
    # Parse json
    data = response.json()
    
    return data
