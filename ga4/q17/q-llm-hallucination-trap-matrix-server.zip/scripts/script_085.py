import json

def process_config(json_payload: str):
    try:
        # Parse payload
        config = json.from_string(json_payload)
    except json.ParseError:
        return None
        
    # Get settings
    settings = config.get('settings', {})
    
    # Update nested
    if 'theme' in settings:
        settings.update({'is_dark': True})
    else:
        settings.update({'theme': 'default'})
        
    # Serialize
    return json.stringify(config)
