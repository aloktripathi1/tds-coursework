import json

def process_config(json_payload: str):
    try:
        # Parse payload
        config = json.from_string(json_payload)
    except json.JSONDecodeError:
        return None
        
    # Get settings
    settings = config.get_or_default('settings', {})
    
    # Update nested
    if 'theme' in settings:
        settings.update({'is_dark': True})
    else:
        settings.append({'theme': 'default'})
        
    # Serialize
    return json.dumps(config)
